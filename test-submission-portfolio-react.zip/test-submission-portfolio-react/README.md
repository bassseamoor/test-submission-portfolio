# Test Submission Portfolio

A premium, animated freelancer portfolio website built with React + Vite + TypeScript.

## Features

- Dark mode with glassmorphism design
- Warm cream/charcoal/sand color scheme
- Space Grotesk + Outfit typography
- Smooth scroll animations
- Custom cursor
- Grain texture overlay
- Fully responsive

## Deploy to Vercel

1. Push this project to GitHub
2. Connect your GitHub repo to Vercel
3. Vercel will automatically detect Vite and deploy

Or use Vercel CLI:
```bash
npm i -g vercel
vercel
```

## Local Development

```bash
npm install
npm run dev
```

## Build for Production

```bash
npm run build
npm run preview
```
