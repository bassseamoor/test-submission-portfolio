import { useEffect, useState } from 'react'

function App() {
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 })
  const [cursorHover, setCursorHover] = useState(false)
  const [activeSection, setActiveSection] = useState('')
  const [activeFaq, setActiveFaq] = useState<number | null>(null)
  const [revealed, setRevealed] = useState<Set<string>>(new Set())

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY })
    }

    const interactiveElements = document.querySelectorAll('a, button, .glass-card')
    interactiveElements.forEach(el => {
      el.addEventListener('mouseenter', () => setCursorHover(true))
      el.addEventListener('mouseleave', () => setCursorHover(false))
    })

    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setRevealed((prev) => new Set([...prev, entry.target.id]))
          }
        })
      },
      { threshold: 0.1 }
    )

    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el))

    const sections = document.querySelectorAll('section[id]')
    const handleScroll = () => {
      let current = ''
      sections.forEach((section) => {
        const rect = section.getBoundingClientRect()
        if (rect.top <= 200 && rect.bottom >= 200) {
          current = section.id
        }
      })
      setActiveSection(current)
    }

    window.addEventListener('scroll', handleScroll)
    return () => {
      observer.disconnect()
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  const faqs = [
    { q: "What's your typical turnaround time?", a: "Most projects are completed within 2-4 weeks, depending on scope and complexity. Rush delivery is available for an additional fee." },
    { q: "How many revisions are included?", a: "I offer unlimited revisions until you're 100% satisfied with the result. Your vision comes first." },
    { q: "Do you only work with Shopify?", a: "Yes, I specialize exclusively in Shopify. This focus allows me to master the platform and deliver exceptional results." },
    { q: "Do you offer post-launch support?", a: "Absolutely. I provide 30 days of free post-launch support, and longer-term maintenance plans are available." },
  ]

  return (
    <>
      <div className="cursor" style={{ left: cursorPos.x - 6, top: cursorPos.y - 6 }} className={cursorHover ? 'cursor hover' : 'cursor'} />

      <div className="grain" />

      <nav>
        <a href="#" className="logo" onClick={(e) => { e.preventDefault(); scrollTo('hero') }}>TS.</a>
        <ul className="nav-links">
          {['about', 'services', 'process', 'faq'].map((id) => (
            <li key={id}>
              <a href={`#${id}`} className={activeSection === id ? 'active' : ''} onClick={(e) => { e.preventDefault(); scrollTo(id) }}>
                {id.charAt(0).toUpperCase() + id.slice(1)}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      <section className="hero" id="hero">
        <div className="hero-bg" />
        <div className="hero-content">
          <span className="hero-label reveal">Available for Projects</span>
          <h1 className="reveal reveal-delay-1">Test Submission</h1>
          <p className="hero-subtitle reveal reveal-delay-2">Portfolio Designer</p>
          <p className="hero-tagline reveal reveal-delay-3">
            Shopify theme design, storefront setup, and brand-focused product merchandising for founders, creators, and service businesses who need a polished online presence.
          </p>
          <button className="btn reveal reveal-delay-4" onClick={() => scrollTo('services')}>
            View My Work
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </section>

      <section id="about">
        <div className="container">
          <div className="section-header reveal">
            <span className="section-label">About</span>
            <h2>Crafting Digital Experiences</h2>
          </div>
          <div className="about-grid">
            <div className="about-text reveal">
              <p>I specialize in creating polished Shopify stores that help founders and creators establish a premium online presence. My approach combines clean design aesthetics with conversion-focused functionality.</p>
              <p>Every project is an opportunity to tell your brand's story through thoughtful design, strategic merchandising, and attention to the details that matter most to your customers.</p>
              <button className="btn" onClick={() => scrollTo('services')}>Learn More</button>
            </div>
            <div className="about-stats reveal reveal-delay-2">
              {[
                { num: '50+', label: 'Projects Delivered' },
                { num: '100%', label: 'Client Satisfaction' },
                { num: '48h', label: 'Avg Response Time' },
              ].map((stat) => (
                <div className="stat" key={stat.label}>
                  <span className="stat-number">{stat.num}</span>
                  <span className="stat-label">{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="services">
        <div className="container">
          <div className="section-header reveal">
            <span className="section-label">Services</span>
            <h2>What I Do</h2>
          </div>
          <div className="services-grid">
            {[
              {
                icon: <svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>,
                title: 'Shopify Theme Design',
                desc: 'Custom themes built to convert. Every element is designed with your brand and customers in mind.'
              },
              {
                icon: <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>,
                title: 'Storefront Setup',
                desc: 'Launch-ready Shopify stores configured for success. From payments to shipping.'
              },
              {
                icon: <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>,
                title: 'Product Merchandising',
                desc: 'Brand-aligned product presentation that sells. Strategic descriptions and cohesive imagery.'
              },
            ].map((service, i) => (
              <div className={`glass-card service-card reveal ${i > 0 ? `reveal-delay-${i}` : ''}`} key={service.title}>
                <div className="service-icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="why">
        <div className="container">
          <div className="section-header reveal">
            <span className="section-label">Why Work With Me</span>
            <h2>Value That Matters</h2>
          </div>
          <div className="why-grid">
            {[
              { num: '01', title: 'Clear Communication', desc: 'Regular updates, no jargon, and always available to discuss your vision.' },
              { num: '02', title: 'Polished Work', desc: 'Every pixel matters. I obsess over the details that elevate your store.' },
              { num: '03', title: 'Fast Turnaround', desc: 'Respect for your timeline. Projects delivered on schedule.' },
            ].map((item, i) => (
              <div className={`glass-card why-item reveal ${i > 0 ? `reveal-delay-${i}` : ''}`} key={item.title}>
                <span className="why-number">{item.num}</span>
                <h3>{item.title}</h3>
                <p>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="process">
        <div className="container">
          <div className="section-header reveal">
            <span className="section-label">Process</span>
            <h2>How We Work Together</h2>
          </div>
          <div className="process-grid">
            {[
              { step: '1', title: 'Discovery Call', desc: 'Understand your brand, goals, and requirements' },
              { step: '2', title: 'Design & Build', desc: 'Create your custom Shopify store' },
              { step: '3', title: 'Review & Refine', desc: 'Polish every detail together' },
              { step: '4', title: 'Launch & Support', desc: 'Go live with ongoing assistance' },
            ].map((item, i) => (
              <div className={`process-step reveal ${i > 0 ? `reveal-delay-${i}` : ''}`} key={item.title}>
                <div className="step-number">{item.step}</div>
                <h3>{item.title}</h3>
                <p>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="testimonials">
        <div className="container">
          <div className="section-header reveal">
            <span className="section-label">Testimonials</span>
            <h2>What Clients Say</h2>
          </div>
          <div className="glass-card testimonial-card reveal">
            <p className="testimonial-quote">Clear communication, polished work, and a fast turnaround. The attention to detail exceeded my expectations.</p>
            <span className="testimonial-author">Happy Client</span>
          </div>
        </div>
      </section>

      <section id="faq">
        <div className="container">
          <div className="section-header reveal">
            <span className="section-label">FAQ</span>
            <h2>Common Questions</h2>
          </div>
          <div className="faq-list">
            {faqs.map((faq, i) => (
              <div className={`faq-item reveal ${activeFaq === i ? 'active' : ''} ${i > 0 ? `reveal-delay-${Math.min(i, 3)}` : ''}`} key={i}>
                <button className="faq-question" onClick={() => setActiveFaq(activeFaq === i ? null : i)}>
                  {faq.q}
                  <span className="faq-icon">
                    <svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6" /></svg>
                  </span>
                </button>
                <div className="faq-answer">
                  <p>{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container reveal">
          <h2>Let's Build Something Amazing</h2>
          <p>Ready to elevate your online presence? Get in touch and let's discuss your project.</p>
          <a href="mailto:test+moorebymoore@example.com" className="btn">
            Contact Me
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </a>
        </div>
      </section>

      <footer>
        <div className="container">
          <p>&copy; 2024 Test Submission. All rights reserved. | <a href="mailto:test+moorebymoore@example.com">test+moorebymoore@example.com</a></p>
        </div>
      </footer>
    </>
  )
}

export default App
